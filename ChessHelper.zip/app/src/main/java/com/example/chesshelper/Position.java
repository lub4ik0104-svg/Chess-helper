package com.example.chesshelper;

import java.util.Arrays;

/**
 * Шахова позиція: правила, генерація ходів, FEN, SAN.
 * Чиста Java, без залежностей від Android.
 *
 * Клітинки: індекс = горизонталь * 8 + вертикаль (a1 = 0, h1 = 7, a8 = 56, h8 = 63).
 * Фігури: білі 1..6, чорні -1..-6 (пішак, кінь, слон, тура, ферзь, король).
 * Хід кодується в int: from | to << 6 | promo << 12.
 */
public class Position {
    public static final int PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6;
    public static final String START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

    public final int[] board = new int[64];
    public boolean whiteToMove = true;
    /** 1 = білі коротка, 2 = білі довга, 4 = чорні коротка, 8 = чорні довга. */
    public int castling = 15;
    public int ep = -1;
    public int halfmove = 0;
    public int fullmove = 1;
    private final int[] kingSq = new int[2];

    private static final int MAXH = 2048;
    private final int[] hMove = new int[MAXH];
    private final int[] hCap = new int[MAXH];
    private final int[] hCast = new int[MAXH];
    private final int[] hEp = new int[MAXH];
    private final int[] hHalf = new int[MAXH];
    private int hp = 0;

    private static final int[] KDR = {1, 2, 2, 1, -1, -2, -2, -1};
    private static final int[] KDF = {2, 1, -1, -2, -2, -1, 1, 2};
    private static final int[] GDR = {1, 1, 1, 0, 0, -1, -1, -1};
    private static final int[] GDF = {-1, 0, 1, -1, 1, -1, 0, 1};
    private static final int[] DDR = {1, 1, -1, -1};
    private static final int[] DDF = {1, -1, 1, -1};
    private static final int[] ODR = {1, -1, 0, 0};
    private static final int[] ODF = {0, 0, 1, -1};
    private static final int[] CASTLE_MASK = new int[64];
    private static final char[] LETTER = {' ', ' ', 'N', 'B', 'R', 'Q', 'K'};

    static {
        Arrays.fill(CASTLE_MASK, 15);
        CASTLE_MASK[0] = 13;
        CASTLE_MASK[7] = 14;
        CASTLE_MASK[4] = 12;
        CASTLE_MASK[56] = 7;
        CASTLE_MASK[63] = 11;
        CASTLE_MASK[60] = 3;
    }

    // ---------- кодування ходів ----------

    public static int mv(int from, int to, int promo) {
        return from | (to << 6) | (promo << 12);
    }

    public static int from(int m) {
        return m & 63;
    }

    public static int to(int m) {
        return (m >> 6) & 63;
    }

    public static int promo(int m) {
        return (m >> 12) & 7;
    }

    public static String sqName(int sq) {
        return "" + (char) ('a' + (sq & 7)) + (char) ('1' + (sq >> 3));
    }

    public static String uci(int m) {
        String s = sqName(from(m)) + sqName(to(m));
        int p = promo(m);
        if (p != 0) s += "pnbrqk".charAt(p - 1);
        return s;
    }

    // ---------- створення ----------

    public static Position startPosition() {
        return fromFen(START_FEN);
    }

    public Position copy() {
        Position c = new Position();
        System.arraycopy(board, 0, c.board, 0, 64);
        c.whiteToMove = whiteToMove;
        c.castling = castling;
        c.ep = ep;
        c.halfmove = halfmove;
        c.fullmove = fullmove;
        c.kingSq[0] = kingSq[0];
        c.kingSq[1] = kingSq[1];
        return c;
    }

    public static Position fromFen(String fen) {
        if (fen == null) throw new IllegalArgumentException("Порожній FEN");
        String[] p = fen.trim().split("\\s+");
        if (p.length < 2) throw new IllegalArgumentException("У FEN замало полів");
        String[] rows = p[0].split("/");
        if (rows.length != 8) throw new IllegalArgumentException("У FEN має бути 8 горизонталей");
        Position pos = new Position();
        int wk = 0, bk = 0;
        for (int i = 0; i < 8; i++) {
            int r = 7 - i;
            int f = 0;
            for (char ch : rows[i].toCharArray()) {
                if (ch >= '1' && ch <= '8') {
                    f += ch - '0';
                } else {
                    int idx = "pnbrqk".indexOf(Character.toLowerCase(ch));
                    if (idx < 0 || f > 7) throw new IllegalArgumentException("Незрозуміла фігура: " + ch);
                    int type = idx + 1;
                    if (type == PAWN && (r == 0 || r == 7))
                        throw new IllegalArgumentException("Пішак на крайній горизонталі");
                    int sq = r * 8 + f;
                    boolean white = Character.isUpperCase(ch);
                    pos.board[sq] = white ? type : -type;
                    if (type == KING) {
                        pos.kingSq[white ? 0 : 1] = sq;
                        if (white) wk++;
                        else bk++;
                    }
                    f++;
                }
            }
            if (f != 8) throw new IllegalArgumentException("Горизонталь " + (r + 1) + " має не 8 клітинок");
        }
        if (wk != 1 || bk != 1) throw new IllegalArgumentException("Має бути рівно по одному королю");
        if (p[1].equals("w")) pos.whiteToMove = true;
        else if (p[1].equals("b")) pos.whiteToMove = false;
        else throw new IllegalArgumentException("Черга ходу має бути w або b");
        pos.castling = 0;
        if (p.length > 2 && !p[2].equals("-")) {
            for (char ch : p[2].toCharArray()) {
                if (ch == 'K') pos.castling |= 1;
                else if (ch == 'Q') pos.castling |= 2;
                else if (ch == 'k') pos.castling |= 4;
                else if (ch == 'q') pos.castling |= 8;
            }
        }
        // права на рокіровку лише якщо король і тура на місці
        if (pos.board[4] != KING || pos.board[7] != ROOK) pos.castling &= ~1;
        if (pos.board[4] != KING || pos.board[0] != ROOK) pos.castling &= ~2;
        if (pos.board[60] != -KING || pos.board[63] != -ROOK) pos.castling &= ~4;
        if (pos.board[60] != -KING || pos.board[56] != -ROOK) pos.castling &= ~8;
        pos.ep = -1;
        if (p.length > 3 && p[3].length() == 2 && !p[3].equals("-")) {
            int f = p[3].charAt(0) - 'a', r = p[3].charAt(1) - '1';
            if (f >= 0 && f < 8 && r >= 0 && r < 8) pos.ep = r * 8 + f;
        }
        try {
            if (p.length > 4) pos.halfmove = Integer.parseInt(p[4]);
            if (p.length > 5) pos.fullmove = Math.max(1, Integer.parseInt(p[5]));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Лічильники ходів у FEN неправильні");
        }
        // той, хто не ходить, не може стояти під шахом
        boolean oppWhite = !pos.whiteToMove;
        if (pos.isAttacked(pos.kingSq[oppWhite ? 0 : 1], pos.whiteToMove))
            throw new IllegalArgumentException("Недопустима позиція: король того, хто не ходить, під шахом");
        return pos;
    }

    public String toFen() {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int empty = 0;
            for (int f = 0; f < 8; f++) {
                int p = board[r * 8 + f];
                if (p == 0) {
                    empty++;
                } else {
                    if (empty > 0) {
                        sb.append(empty);
                        empty = 0;
                    }
                    char ch = "pnbrqk".charAt(Math.abs(p) - 1);
                    sb.append(p > 0 ? Character.toUpperCase(ch) : ch);
                }
            }
            if (empty > 0) sb.append(empty);
            if (r > 0) sb.append('/');
        }
        sb.append(whiteToMove ? " w " : " b ");
        if (castling == 0) sb.append('-');
        else {
            if ((castling & 1) != 0) sb.append('K');
            if ((castling & 2) != 0) sb.append('Q');
            if ((castling & 4) != 0) sb.append('k');
            if ((castling & 8) != 0) sb.append('q');
        }
        sb.append(' ').append(ep < 0 ? "-" : sqName(ep));
        sb.append(' ').append(halfmove).append(' ').append(fullmove);
        return sb.toString();
    }

    // ---------- атаки ----------

    /** Чи б'є клітинку sq будь-яка фігура вказаного кольору (швидка версія для пошуку). */
    public boolean isAttacked(int sq, boolean byWhite) {
        int s = byWhite ? 1 : -1;
        int r = sq >> 3, f = sq & 7;
        int pr = r - s;
        if (pr >= 0 && pr < 8) {
            if (f > 0 && board[pr * 8 + f - 1] == s * PAWN) return true;
            if (f < 7 && board[pr * 8 + f + 1] == s * PAWN) return true;
        }
        for (int k = 0; k < 8; k++) {
            int nr = r + KDR[k], nf = f + KDF[k];
            if (nr >= 0 && nr < 8 && nf >= 0 && nf < 8 && board[nr * 8 + nf] == s * KNIGHT) return true;
        }
        for (int k = 0; k < 8; k++) {
            int nr = r + GDR[k], nf = f + GDF[k];
            if (nr >= 0 && nr < 8 && nf >= 0 && nf < 8 && board[nr * 8 + nf] == s * KING) return true;
        }
        for (int d = 0; d < 4; d++) {
            int nr = r + DDR[d], nf = f + DDF[d];
            while (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                int p = board[nr * 8 + nf];
                if (p != 0) {
                    if (p == s * BISHOP || p == s * QUEEN) return true;
                    break;
                }
                nr += DDR[d];
                nf += DDF[d];
            }
        }
        for (int d = 0; d < 4; d++) {
            int nr = r + ODR[d], nf = f + ODF[d];
            while (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                int p = board[nr * 8 + nf];
                if (p != 0) {
                    if (p == s * ROOK || p == s * QUEEN) return true;
                    break;
                }
                nr += ODR[d];
                nf += ODF[d];
            }
        }
        return false;
    }

    private boolean ray(int sq, int[] dr, int[] df, int target) {
        int r = sq >> 3, f = sq & 7;
        for (int d = 0; d < 4; d++) {
            int nr = r + dr[d], nf = f + df[d];
            while (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                int p = board[nr * 8 + nf];
                if (p != 0) {
                    if (p == target) return true;
                    break;
                }
                nr += dr[d];
                nf += df[d];
            }
        }
        return false;
    }

    private boolean attackedByType(int sq, boolean byWhite, int type) {
        int s = byWhite ? 1 : -1;
        int r = sq >> 3, f = sq & 7;
        switch (type) {
            case PAWN: {
                int pr = r - s;
                if (pr < 0 || pr > 7) return false;
                if (f > 0 && board[pr * 8 + f - 1] == s * PAWN) return true;
                return f < 7 && board[pr * 8 + f + 1] == s * PAWN;
            }
            case KNIGHT:
                for (int k = 0; k < 8; k++) {
                    int nr = r + KDR[k], nf = f + KDF[k];
                    if (nr >= 0 && nr < 8 && nf >= 0 && nf < 8 && board[nr * 8 + nf] == s * KNIGHT) return true;
                }
                return false;
            case KING:
                for (int k = 0; k < 8; k++) {
                    int nr = r + GDR[k], nf = f + GDF[k];
                    if (nr >= 0 && nr < 8 && nf >= 0 && nf < 8 && board[nr * 8 + nf] == s * KING) return true;
                }
                return false;
            default: {
                boolean diag = type == BISHOP || type == QUEEN;
                boolean orth = type == ROOK || type == QUEEN;
                if (diag && ray(sq, DDR, DDF, s * type)) return true;
                return orth && ray(sq, ODR, ODF, s * type);
            }
        }
    }

    /** Тип найдешевшої фігури вказаного кольору, що б'є клітинку (0 — ніхто не б'є). */
    public int leastAttacker(int sq, boolean byWhite) {
        for (int t = PAWN; t <= KING; t++) {
            if (attackedByType(sq, byWhite, t)) return t;
        }
        return 0;
    }

    /** Чи стоїть король того, чия черга ходити, під шахом. */
    public boolean inCheck() {
        return isAttacked(kingSq[whiteToMove ? 0 : 1], !whiteToMove);
    }

    /** Після make(): чи залишив той, хто щойно походив, свого короля під боєм. */
    public boolean moverInCheck() {
        return isAttacked(kingSq[whiteToMove ? 1 : 0], whiteToMove);
    }

    // ---------- генерація ходів ----------

    private static int addPromos(int[] out, int n, int from, int to, boolean capsOnly) {
        out[n++] = mv(from, to, QUEEN);
        if (!capsOnly) {
            out[n++] = mv(from, to, ROOK);
            out[n++] = mv(from, to, BISHOP);
            out[n++] = mv(from, to, KNIGHT);
        }
        return n;
    }

    private int slide(int[] out, int n, int sq, int[] dr, int[] df, boolean capsOnly) {
        int r = sq >> 3, f = sq & 7;
        for (int d = 0; d < 4; d++) {
            int nr = r + dr[d], nf = f + df[d];
            while (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                int to = nr * 8 + nf;
                int tp = board[to];
                if (tp == 0) {
                    if (!capsOnly) out[n++] = mv(sq, to, 0);
                } else {
                    if ((tp > 0) != whiteToMove) out[n++] = mv(sq, to, 0);
                    break;
                }
                nr += dr[d];
                nf += df[d];
            }
        }
        return n;
    }

    /** Псевдолегальні ходи (король може лишитися під шахом). Масив out — не менше 256. */
    public int gen(int[] out, boolean capsOnly) {
        int n = 0;
        int side = whiteToMove ? 1 : -1;
        for (int sq = 0; sq < 64; sq++) {
            int p = board[sq];
            if (p == 0 || (p > 0) != whiteToMove) continue;
            int t = Math.abs(p);
            int r = sq >> 3, f = sq & 7;
            switch (t) {
                case PAWN: {
                    int startRank = whiteToMove ? 1 : 6;
                    int lastRank = whiteToMove ? 7 : 0;
                    int nr = r + side;
                    if (nr < 0 || nr > 7) break;
                    int to = nr * 8 + f;
                    if (board[to] == 0) {
                        if (nr == lastRank) {
                            n = addPromos(out, n, sq, to, capsOnly);
                        } else if (!capsOnly) {
                            out[n++] = mv(sq, to, 0);
                            if (r == startRank && board[to + 8 * side] == 0) out[n++] = mv(sq, to + 8 * side, 0);
                        }
                    }
                    for (int df = -1; df <= 1; df += 2) {
                        int nf = f + df;
                        if (nf < 0 || nf > 7) continue;
                        int cs = nr * 8 + nf;
                        int tp = board[cs];
                        if (tp != 0 && (tp > 0) != whiteToMove) {
                            if (nr == lastRank) n = addPromos(out, n, sq, cs, capsOnly);
                            else out[n++] = mv(sq, cs, 0);
                        } else if (tp == 0 && cs == ep) {
                            out[n++] = mv(sq, cs, 0);
                        }
                    }
                    break;
                }
                case KNIGHT:
                    for (int k = 0; k < 8; k++) {
                        int nr = r + KDR[k], nf = f + KDF[k];
                        if (nr < 0 || nr > 7 || nf < 0 || nf > 7) continue;
                        int to = nr * 8 + nf;
                        int tp = board[to];
                        if (tp == 0) {
                            if (!capsOnly) out[n++] = mv(sq, to, 0);
                        } else if ((tp > 0) != whiteToMove) {
                            out[n++] = mv(sq, to, 0);
                        }
                    }
                    break;
                case BISHOP:
                    n = slide(out, n, sq, DDR, DDF, capsOnly);
                    break;
                case ROOK:
                    n = slide(out, n, sq, ODR, ODF, capsOnly);
                    break;
                case QUEEN:
                    n = slide(out, n, sq, DDR, DDF, capsOnly);
                    n = slide(out, n, sq, ODR, ODF, capsOnly);
                    break;
                case KING:
                    for (int k = 0; k < 8; k++) {
                        int nr = r + GDR[k], nf = f + GDF[k];
                        if (nr < 0 || nr > 7 || nf < 0 || nf > 7) continue;
                        int to = nr * 8 + nf;
                        int tp = board[to];
                        if (tp == 0) {
                            if (!capsOnly) out[n++] = mv(sq, to, 0);
                        } else if ((tp > 0) != whiteToMove) {
                            out[n++] = mv(sq, to, 0);
                        }
                    }
                    if (!capsOnly) {
                        if (whiteToMove && sq == 4) {
                            if ((castling & 1) != 0 && board[5] == 0 && board[6] == 0 && board[7] == ROOK
                                    && !isAttacked(4, false) && !isAttacked(5, false))
                                out[n++] = mv(4, 6, 0);
                            if ((castling & 2) != 0 && board[1] == 0 && board[2] == 0 && board[3] == 0
                                    && board[0] == ROOK && !isAttacked(4, false) && !isAttacked(3, false))
                                out[n++] = mv(4, 2, 0);
                        } else if (!whiteToMove && sq == 60) {
                            if ((castling & 4) != 0 && board[61] == 0 && board[62] == 0 && board[63] == -ROOK
                                    && !isAttacked(60, true) && !isAttacked(61, true))
                                out[n++] = mv(60, 62, 0);
                            if ((castling & 8) != 0 && board[57] == 0 && board[58] == 0 && board[59] == 0
                                    && board[56] == -ROOK && !isAttacked(60, true) && !isAttacked(59, true))
                                out[n++] = mv(60, 58, 0);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        return n;
    }

    public int[] legalMoves() {
        int[] tmp = new int[256];
        int n = gen(tmp, false);
        int[] res = new int[n];
        int c = 0;
        for (int i = 0; i < n; i++) {
            make(tmp[i]);
            if (!moverInCheck()) res[c++] = tmp[i];
            unmake();
        }
        return Arrays.copyOf(res, c);
    }

    public boolean hasLegalMove() {
        int[] tmp = new int[256];
        int n = gen(tmp, false);
        for (int i = 0; i < n; i++) {
            make(tmp[i]);
            boolean ok = !moverInCheck();
            unmake();
            if (ok) return true;
        }
        return false;
    }

    // ---------- виконання ходів ----------

    public void make(int m) {
        int from = m & 63, to = (m >> 6) & 63, promo = (m >> 12) & 7;
        int piece = board[from];
        int type = Math.abs(piece);
        int side = piece > 0 ? 1 : -1;
        int cap = board[to];
        boolean isEp = type == PAWN && to == ep && (from & 7) != (to & 7) && cap == 0;
        if (isEp) cap = board[to - 8 * side];
        hMove[hp] = m;
        hCap[hp] = cap;
        hCast[hp] = castling;
        hEp[hp] = ep;
        hHalf[hp] = halfmove;
        hp++;
        if (isEp) board[to - 8 * side] = 0;
        board[to] = promo != 0 ? side * promo : piece;
        board[from] = 0;
        if (type == KING) {
            kingSq[side > 0 ? 0 : 1] = to;
            if (Math.abs(to - from) == 2) {
                if (to > from) {
                    board[to - 1] = board[to + 1];
                    board[to + 1] = 0;
                } else {
                    board[to + 1] = board[to - 2];
                    board[to - 2] = 0;
                }
            }
        }
        castling &= CASTLE_MASK[from] & CASTLE_MASK[to];
        ep = (type == PAWN && Math.abs(to - from) == 16) ? (from + to) / 2 : -1;
        halfmove = (type == PAWN || cap != 0) ? 0 : halfmove + 1;
        if (!whiteToMove) fullmove++;
        whiteToMove = !whiteToMove;
    }

    public void unmake() {
        hp--;
        int m = hMove[hp];
        int from = m & 63, to = (m >> 6) & 63, promo = (m >> 12) & 7;
        whiteToMove = !whiteToMove;
        int side = whiteToMove ? 1 : -1;
        int moved = promo != 0 ? side * PAWN : board[to];
        int type = Math.abs(moved);
        int cap = hCap[hp];
        int prevEp = hEp[hp];
        board[from] = moved;
        if (type == PAWN && to == prevEp && (from & 7) != (to & 7)) {
            board[to] = 0;
            board[to - 8 * side] = cap;
        } else {
            board[to] = cap;
        }
        if (type == KING) {
            kingSq[whiteToMove ? 0 : 1] = from;
            if (Math.abs(to - from) == 2) {
                if (to > from) {
                    board[to + 1] = board[to - 1];
                    board[to - 1] = 0;
                } else {
                    board[to - 2] = board[to + 1];
                    board[to + 1] = 0;
                }
            }
        }
        castling = hCast[hp];
        ep = prevEp;
        halfmove = hHalf[hp];
        if (!whiteToMove) fullmove--;
    }

    // ---------- стан гри ----------

    public boolean isInsufficientMaterial() {
        int minors = 0;
        for (int sq = 0; sq < 64; sq++) {
            int t = Math.abs(board[sq]);
            if (t == PAWN || t == ROOK || t == QUEEN) return false;
            if (t == KNIGHT || t == BISHOP) minors++;
        }
        return minors <= 1;
    }

    // ---------- запис ходу ----------

    /** Хід у алгебраїчній нотації (SAN), наприклад Nf3, exd5, O-O, e8=Q+. */
    public String san(int m) {
        int from = from(m), to = to(m), promo = promo(m);
        int piece = board[from];
        int type = Math.abs(piece);
        boolean capture = board[to] != 0 || (type == PAWN && to == ep && (from & 7) != (to & 7));
        StringBuilder sb = new StringBuilder();
        if (type == KING && Math.abs(to - from) == 2) {
            sb.append(to > from ? "O-O" : "O-O-O");
        } else {
            if (type != PAWN) {
                sb.append(LETTER[type]);
                boolean clash = false, sameFile = false, sameRank = false;
                for (int o : legalMoves()) {
                    int of = from(o), ot = to(o);
                    if (o != m && ot == to && of != from && board[of] == piece) {
                        clash = true;
                        if ((of & 7) == (from & 7)) sameFile = true;
                        if ((of >> 3) == (from >> 3)) sameRank = true;
                    }
                }
                if (clash) {
                    if (!sameFile) sb.append((char) ('a' + (from & 7)));
                    else if (!sameRank) sb.append((char) ('1' + (from >> 3)));
                    else sb.append(sqName(from));
                }
            } else if (capture) {
                sb.append((char) ('a' + (from & 7)));
            }
            if (capture) sb.append('x');
            sb.append(sqName(to));
            if (promo != 0) sb.append('=').append(LETTER[promo]);
        }
        make(m);
        if (inCheck()) sb.append(hasLegalMove() ? '+' : '#');
        unmake();
        return sb.toString();
    }
}

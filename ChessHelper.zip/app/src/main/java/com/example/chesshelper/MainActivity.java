package com.example.chesshelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity implements BoardView.Listener {
    private static final String[] STRENGTH_NAMES = {"Швидко (1 с)", "Нормально (3 с)", "Глибоко (8 с)"};
    private static final long[] STRENGTH_MS = {1000, 3000, 8000};

    private Position pos = Position.startPosition();
    private final ArrayList<Integer> played = new ArrayList<>();
    private int[] legal = new int[0];
    private int selected = -1;
    private int hintMove = 0;
    private boolean gameOver = false;
    private boolean autoHint = true;
    private long thinkMs = 3000;
    private int searchId = 0;

    private BoardView board;
    private TextView statusView;
    private TextView hintView;
    private Button playHintButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(10), dp(10), dp(16));
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("Шахи: підказка найкращого ходу");
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setPadding(0, dp(4), 0, dp(6));
        root.addView(statusView);

        board = new BoardView(this);
        board.setListener(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(board, blp);

        Button hintBtn = makeButton("Підказка", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!gameOver) requestHint();
            }
        });
        playHintButton = makeButton("Зіграти хід", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hintMove != 0 && !gameOver) applyMove(hintMove);
            }
        });
        Button undoBtn = makeButton("Назад", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                undo();
            }
        });
        root.addView(makeRow(hintBtn, playHintButton, undoBtn));

        Button newBtn = makeButton("Нова гра", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos = Position.startPosition();
                played.clear();
                afterPositionChanged(true);
            }
        });
        Button flipBtn = makeButton("Повернути", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.setFlipped(!board.isFlipped());
            }
        });
        Button fenBtn = makeButton("FEN", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFenDialog();
            }
        });
        root.addView(makeRow(newBtn, flipBtn, fenBtn));

        CheckBox auto = new CheckBox(this);
        auto.setText("Показувати підказку після кожного ходу");
        auto.setChecked(true);
        auto.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                autoHint = checked;
                if (checked && !gameOver && hintMove == 0) requestHint();
            }
        });
        root.addView(auto);

        Spinner strength = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, STRENGTH_NAMES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        strength.setAdapter(adapter);
        strength.setSelection(1);
        strength.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                thinkMs = STRENGTH_MS[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(strength);

        hintView = new TextView(this);
        hintView.setTextSize(15);
        hintView.setPadding(dp(2), dp(10), dp(2), dp(10));
        hintView.setTextIsSelectable(true);
        root.addView(hintView);

        setContentView(scroll);
        afterPositionChanged(true);
    }

    // ---------- допоміжне для інтерфейсу ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button makeButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout makeRow(Button... buttons) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (Button b : buttons) {
            row.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        return row;
    }

    // ---------- ігрова логіка ----------

    @Override
    public void onSquareTapped(int sq) {
        if (gameOver) return;
        if (selected != -1) {
            int found = 0;
            boolean promotion = false;
            for (int m : legal) {
                if (Position.from(m) == selected && Position.to(m) == sq) {
                    found = m;
                    if (Position.promo(m) != 0) promotion = true;
                }
            }
            if (found != 0) {
                if (promotion) askPromotion(selected, sq);
                else applyMove(found);
                return;
            }
        }
        int p = pos.board[sq];
        if (p != 0 && (p > 0) == pos.whiteToMove) {
            select(sq);
        } else {
            selected = -1;
            board.setSelection(-1, new int[0]);
        }
    }

    private void select(int sq) {
        selected = sq;
        int count = 0;
        int[] tmp = new int[legal.length];
        for (int m : legal) {
            if (Position.from(m) == sq) tmp[count++] = Position.to(m);
        }
        int[] t = new int[count];
        System.arraycopy(tmp, 0, t, 0, count);
        board.setSelection(sq, t);
    }

    private void askPromotion(final int from, final int to) {
        final int[] types = {Position.QUEEN, Position.ROOK, Position.BISHOP, Position.KNIGHT};
        String[] names = {"Ферзь", "Тура", "Слон", "Кінь"};
        new AlertDialog.Builder(this)
                .setTitle("Перетворення пішака")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        applyMove(Position.mv(from, to, types[which]));
                    }
                })
                .show();
    }

    private void applyMove(int m) {
        pos.make(m);
        played.add(m);
        afterPositionChanged(true);
    }

    private void undo() {
        if (played.isEmpty()) return;
        pos.unmake();
        played.remove(played.size() - 1);
        afterPositionChanged(true);
    }

    private void afterPositionChanged(boolean allowAuto) {
        searchId++;
        selected = -1;
        hintMove = 0;
        legal = pos.legalMoves();
        board.setPosition(pos);
        board.setSelection(-1, new int[0]);
        board.setHint(-1, -1);
        if (played.isEmpty()) {
            board.setLastMove(-1, -1);
        } else {
            int last = played.get(played.size() - 1);
            board.setLastMove(Position.from(last), Position.to(last));
        }
        updateStatus();
        playHintButton.setEnabled(false);
        if (gameOver) {
            hintView.setText("");
        } else if (allowAuto && autoHint) {
            requestHint();
        } else {
            hintView.setText("Натисни «Підказка», щоб побачити найкращий хід.");
        }
    }

    private void updateStatus() {
        String side = pos.whiteToMove ? "білих" : "чорних";
        gameOver = false;
        if (legal.length == 0) {
            gameOver = true;
            if (pos.inCheck()) {
                statusView.setText("Мат! Перемогли " + (pos.whiteToMove ? "чорні" : "білі") + ".");
            } else {
                statusView.setText("Пат — нічия.");
            }
        } else if (pos.halfmove >= 100) {
            gameOver = true;
            statusView.setText("Нічия за правилом 50 ходів.");
        } else if (pos.isInsufficientMaterial()) {
            gameOver = true;
            statusView.setText("Нічия: недостатньо матеріалу для мату.");
        } else {
            statusView.setText("Хід " + side + (pos.inCheck() ? " — ШАХ!" : "") + "   (хід №" + pos.fullmove + ")");
        }
    }

    private void requestHint() {
        final int id = ++searchId;
        hintMove = 0;
        board.setHint(-1, -1);
        playHintButton.setEnabled(false);
        hintView.setText("Думаю…");
        final Position snapshot = pos.copy();
        final long ms = thinkMs;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String text;
                Engine.Result result = null;
                try {
                    result = new Engine().think(snapshot, ms, 30);
                    text = result.move == 0 ? "Ходів немає." : Explainer.format(snapshot, result);
                } catch (Throwable t) {
                    text = "Помилка розрахунку: " + t;
                }
                final String shown = text;
                final Engine.Result res = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (id != searchId) return; // позиція вже змінилась
                        hintView.setText(shown);
                        if (res != null && res.move != 0) {
                            hintMove = res.move;
                            board.setHint(Position.from(res.move), Position.to(res.move));
                            playHintButton.setEnabled(true);
                        }
                    }
                });
            }
        }).start();
    }

    private void showFenDialog() {
        final EditText input = new EditText(this);
        input.setText(pos.toFen());
        input.setSingleLine(false);
        input.setTextSize(13);
        new AlertDialog.Builder(this)
                .setTitle("Позиція у форматі FEN")
                .setMessage("Скопіюй поточну позицію або встав свою й натисни «Завантажити».")
                .setView(input)
                .setPositiveButton("Завантажити", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        try {
                            pos = Position.fromFen(input.getText().toString());
                            played.clear();
                            afterPositionChanged(true);
                        } catch (IllegalArgumentException e) {
                            Toast.makeText(MainActivity.this, "FEN не підійшов: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("Скасувати", null)
                .show();
    }
}

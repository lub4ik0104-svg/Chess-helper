package com.example.chesshelper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

/** Малює шахівницю, фігури, підсвітки та стрілку підказки. */
public class BoardView extends View {
    public interface Listener {
        void onSquareTapped(int sq);
    }

    // Єдиний набір «заповнених» гліфів; колір задає сторону. VS15 (︎) вимикає емодзі-вигляд.
    private static final String[] GLYPH = {
            "", "♟︎", "♞︎", "♝︎", "♜︎", "♛︎", "♚︎"};

    private static final int LIGHT = 0xFFF0D9B5;
    private static final int DARK = 0xFFB58863;

    private Position pos;
    private Listener listener;
    private boolean flipped = false;
    private int selected = -1;
    private int[] targets = new int[0];
    private int hintFrom = -1, hintTo = -1;
    private int lastFrom = -1, lastTo = -1;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pieceFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pieceStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrowHead = new Path();

    public BoardView(Context context) {
        super(context);
        stroke.setStyle(Paint.Style.STROKE);
        pieceFill.setTextAlign(Paint.Align.CENTER);
        pieceStroke.setTextAlign(Paint.Align.CENTER);
        pieceStroke.setStyle(Paint.Style.STROKE);
        label.setTextAlign(Paint.Align.LEFT);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setPosition(Position p) {
        pos = p;
        invalidate();
    }

    public void setFlipped(boolean f) {
        flipped = f;
        invalidate();
    }

    public boolean isFlipped() {
        return flipped;
    }

    public void setSelection(int sq, int[] targetSquares) {
        selected = sq;
        targets = targetSquares;
        invalidate();
    }

    public void setHint(int from, int to) {
        hintFrom = from;
        hintTo = to;
        invalidate();
    }

    public void setLastMove(int from, int to) {
        lastFrom = from;
        lastTo = to;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.72f);
        int size = Math.min(w, maxH);
        if (size <= 0) size = maxH;
        setMeasuredDimension(size, size);
    }

    private int squareAt(int col, int row) {
        int file = flipped ? 7 - col : col;
        int rank = flipped ? row : 7 - row;
        return rank * 8 + file;
    }

    private int colOf(int sq) {
        int file = sq & 7;
        return flipped ? 7 - file : file;
    }

    private int rowOf(int sq) {
        int rank = sq >> 3;
        return flipped ? rank : 7 - rank;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (pos == null) return;
        float cell = getWidth() / 8f;

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                int sq = squareAt(col, row);
                boolean light = ((sq >> 3) + (sq & 7)) % 2 == 1;
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(light ? LIGHT : DARK);
                float x = col * cell, y = row * cell;
                c.drawRect(x, y, x + cell, y + cell, fill);
                if (sq == lastFrom || sq == lastTo) {
                    fill.setColor(0x66FFEB3B);
                    c.drawRect(x, y, x + cell, y + cell, fill);
                }
                if (sq == hintFrom || sq == hintTo) {
                    fill.setColor(0x6642A5F5);
                    c.drawRect(x, y, x + cell, y + cell, fill);
                }
                if (sq == selected) {
                    fill.setColor(0x8866BB6A);
                    c.drawRect(x, y, x + cell, y + cell, fill);
                }
                // координати
                label.setTextSize(cell * 0.2f);
                label.setColor(light ? DARK : LIGHT);
                if (row == 7) c.drawText(String.valueOf((char) ('a' + (sq & 7))), x + cell * 0.82f, y + cell * 0.96f, label);
                if (col == 0) c.drawText(String.valueOf((char) ('1' + (sq >> 3))), x + cell * 0.05f, y + cell * 0.22f, label);
            }
        }

        // можливі ходи вибраної фігури
        for (int t : targets) {
            float cx = (colOf(t) + 0.5f) * cell, cy = (rowOf(t) + 0.5f) * cell;
            if (pos.board[t] == 0) {
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(0x66000000);
                c.drawCircle(cx, cy, cell * 0.16f, fill);
            } else {
                stroke.setColor(0x88000000);
                stroke.setStrokeWidth(cell * 0.08f);
                c.drawCircle(cx, cy, cell * 0.44f, stroke);
            }
        }

        // фігури
        pieceFill.setTextSize(cell * 0.82f);
        pieceStroke.setTextSize(cell * 0.82f);
        pieceStroke.setStrokeWidth(cell * 0.035f);
        Paint.FontMetrics fm = pieceFill.getFontMetrics();
        float baselineShift = -(fm.ascent + fm.descent) / 2f;
        for (int sq = 0; sq < 64; sq++) {
            int p = pos.board[sq];
            if (p == 0) continue;
            float cx = (colOf(sq) + 0.5f) * cell, cy = (rowOf(sq) + 0.5f) * cell + baselineShift;
            String g = GLYPH[Math.abs(p)];
            if (p > 0) {
                pieceStroke.setColor(0xFF222222);
                pieceFill.setColor(0xFFFFFFFF);
            } else {
                pieceStroke.setColor(0xAAFFFFFF);
                pieceFill.setColor(0xFF1A1A1A);
            }
            c.drawText(g, cx, cy, pieceStroke);
            c.drawText(g, cx, cy, pieceFill);
        }

        // стрілка підказки
        if (hintFrom >= 0 && hintTo >= 0) {
            float x1 = (colOf(hintFrom) + 0.5f) * cell, y1 = (rowOf(hintFrom) + 0.5f) * cell;
            float x2 = (colOf(hintTo) + 0.5f) * cell, y2 = (rowOf(hintTo) + 0.5f) * cell;
            float dx = x2 - x1, dy = y2 - y1;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 1f) {
                float ux = dx / len, uy = dy / len;
                float head = cell * 0.34f;
                float ex = x2 - ux * head, ey = y2 - uy * head;
                stroke.setColor(0xCC2E7D32);
                stroke.setStrokeWidth(cell * 0.13f);
                stroke.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(x1, y1, ex, ey, stroke);
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(0xCC2E7D32);
                arrowHead.reset();
                arrowHead.moveTo(x2, y2);
                arrowHead.lineTo(ex - uy * head * 0.6f, ey + ux * head * 0.6f);
                arrowHead.lineTo(ex + uy * head * 0.6f, ey - ux * head * 0.6f);
                arrowHead.close();
                c.drawPath(arrowHead, fill);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getAction();
        if (action == MotionEvent.ACTION_DOWN) return true;
        if (action == MotionEvent.ACTION_UP) {
            performClick();
            float cell = getWidth() / 8f;
            if (cell <= 0) return true;
            int col = (int) (e.getX() / cell), row = (int) (e.getY() / cell);
            if (col >= 0 && col < 8 && row >= 0 && row < 8 && listener != null) {
                listener.onSquareTapped(squareAt(col, row));
            }
            return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}

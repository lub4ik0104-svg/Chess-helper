package com.example.chesshelper;

import java.util.Arrays;

/**
 * Шаховий рушій: ітеративне заглиблення, альфа-бета, квіесцентний пошук,
 * оцінка = матеріал + таблиці полів + пара слонів + прохідні пішаки + тури на відкритих лініях.
 */
public class Engine {
    public static final int MATE = 100000;
    public static final int INF = 1000000;
    public static final int MAXPLY = 64;

    private static final int[] VAL = {0, 100, 320, 330, 500, 900, 0};

    private static final int[] PST_P = {
            0, 0, 0, 0, 0, 0, 0, 0,
            50, 50, 50, 50, 50, 50, 50, 50,
            10, 10, 20, 30, 30, 20, 10, 10,
            5, 5, 10, 25, 25, 10, 5, 5,
            0, 0, 0, 20, 20, 0, 0, 0,
            5, -5, -10, 0, 0, -10, -5, 5,
            5, 10, 10, -20, -20, 10, 10, 5,
            0, 0, 0, 0, 0, 0, 0, 0};
    private static final int[] PST_N = {
            -50, -40, -30, -30, -30, -30, -40, -50,
            -40, -20, 0, 0, 0, 0, -20, -40,
            -30, 0, 10, 15, 15, 10, 0, -30,
            -30, 5, 15, 20, 20, 15, 5, -30,
            -30, 0, 15, 20, 20, 15, 0, -30,
            -30, 5, 10, 15, 15, 10, 5, -30,
            -40, -20, 0, 5, 5, 0, -20, -40,
            -50, -40, -30, -30, -30, -30, -40, -50};
    private static final int[] PST_B = {
            -20, -10, -10, -10, -10, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 10, 10, 5, 0, -10,
            -10, 5, 5, 10, 10, 5, 5, -10,
            -10, 0, 10, 10, 10, 10, 0, -10,
            -10, 10, 10, 10, 10, 10, 10, -10,
            -10, 5, 0, 0, 0, 0, 5, -10,
            -20, -10, -10, -10, -10, -10, -10, -20};
    private static final int[] PST_R = {
            0, 0, 0, 0, 0, 0, 0, 0,
            5, 10, 10, 10, 10, 10, 10, 5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            0, 0, 0, 5, 5, 0, 0, 0};
    private static final int[] PST_Q = {
            -20, -10, -10, -5, -5, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 5, 5, 5, 0, -10,
            -5, 0, 5, 5, 5, 5, 0, -5,
            0, 0, 5, 5, 5, 5, 0, -5,
            -10, 5, 5, 5, 5, 5, 0, -10,
            -10, 0, 5, 0, 0, 0, 0, -10,
            -20, -10, -10, -5, -5, -10, -10, -20};
    private static final int[] PST_KM = {
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -20, -30, -30, -40, -40, -30, -30, -20,
            -10, -20, -20, -20, -20, -20, -20, -10,
            20, 20, 0, 0, 0, 0, 20, 20,
            20, 30, 10, 0, 0, 10, 30, 20};
    private static final int[] PST_KE = {
            -50, -40, -30, -20, -20, -30, -40, -50,
            -30, -20, -10, 0, 0, -10, -20, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30,
            -50, -30, -30, -30, -30, -30, -30, -50};
    private static final int[] PASSED = {0, 5, 10, 20, 35, 60, 100, 0};

    public static class Result {
        public int move = 0;
        public int score = 0; // сантипішаки з точки зору того, хто ходить
        public int depth = 0;
        public long nodes = 0;
        public int[] pv = new int[0];
    }

    private Position pos;
    private long deadline;
    private boolean stop;
    private long nodes;
    private int rootDepth;
    private int rootPrev;
    private final int[][] killers = new int[MAXPLY + 2][2];
    private final int[][] pv = new int[MAXPLY + 2][MAXPLY + 2];
    private final int[] pvLen = new int[MAXPLY + 2];
    private final int[][] moveBuf = new int[MAXPLY + 2][256];
    private final int[][] scoreBuf = new int[MAXPLY + 2][256];
    private final int[] wP = new int[8], bP = new int[8], maxB = new int[8], minW = new int[8];

    /** Сума вартості всіх фігур, крім пішаків і королів (обох сторін). */
    public static int nonPawnMaterial(Position p) {
        int sum = 0;
        for (int sq = 0; sq < 64; sq++) {
            int t = Math.abs(p.board[sq]);
            if (t >= Position.KNIGHT && t <= Position.QUEEN) sum += VAL[t];
        }
        return sum;
    }

    public static boolean isEndgame(Position p) {
        return nonPawnMaterial(p) <= 2600;
    }

    public Result think(Position position, long millis, int maxDepth) {
        this.pos = position.copy();
        Result res = new Result();
        int[] legal = pos.legalMoves();
        if (legal.length == 0) return res;
        res.move = legal[0];
        deadline = System.nanoTime() + millis * 1_000_000L;
        stop = false;
        nodes = 0;
        rootPrev = 0;
        for (int[] k : killers) Arrays.fill(k, 0);
        for (int d = 1; d <= maxDepth; d++) {
            rootDepth = d;
            int score = search(d, -INF, INF, 0);
            if (stop) break;
            if (pvLen[0] == 0 || pv[0][0] == 0) break;
            res.move = pv[0][0];
            res.score = score;
            res.depth = d;
            res.pv = Arrays.copyOfRange(pv[0], 0, pvLen[0]);
            rootPrev = res.move;
            if (Math.abs(score) >= MATE - 100) break;
        }
        res.nodes = nodes;
        return res;
    }

    private int orderScore(int m, int ply) {
        int from = Position.from(m), to = Position.to(m), promo = Position.promo(m);
        int victim = Math.abs(pos.board[to]);
        int attacker = Math.abs(pos.board[from]);
        int s = 0;
        if (victim != 0) s = 100000 + VAL[victim] * 16 - attacker;
        else if (attacker == Position.PAWN && to == pos.ep && (from & 7) != (to & 7)) s = 100000 + VAL[1] * 16 - 1;
        if (promo != 0) s += 90000 + VAL[promo];
        if (s == 0) {
            if (m == killers[ply][0]) s = 90000;
            else if (m == killers[ply][1]) s = 80000;
        }
        if (ply == 0 && m == rootPrev) s = 1_000_000;
        return s;
    }

    private int search(int depth, int alpha, int beta, int ply) {
        pvLen[ply] = ply;
        if ((++nodes & 2047) == 0 && System.nanoTime() > deadline) stop = true;
        if (stop) return 0;
        if (ply > 0 && pos.halfmove >= 100) return 0;
        if (ply >= MAXPLY) return evaluate();
        boolean inCheck = pos.inCheck();
        if (inCheck && ply < rootDepth * 2) depth++;
        if (depth <= 0) return quiesce(alpha, beta, ply);

        int[] moves = moveBuf[ply];
        int[] sc = scoreBuf[ply];
        int n = pos.gen(moves, false);
        for (int i = 0; i < n; i++) sc[i] = orderScore(moves[i], ply);

        int legal = 0;
        for (int i = 0; i < n; i++) {
            int bi = i;
            for (int j = i + 1; j < n; j++) if (sc[j] > sc[bi]) bi = j;
            if (bi != i) {
                int tm = moves[i]; moves[i] = moves[bi]; moves[bi] = tm;
                int ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts;
            }
            int m = moves[i];
            boolean quiet = pos.board[Position.to(m)] == 0 && Position.promo(m) == 0;
            pos.make(m);
            if (pos.moverInCheck()) {
                pos.unmake();
                continue;
            }
            legal++;
            int score = -search(depth - 1, -beta, -alpha, ply + 1);
            pos.unmake();
            if (stop) return 0;
            if (score > alpha) {
                alpha = score;
                pv[ply][ply] = m;
                for (int j = ply + 1; j < pvLen[ply + 1]; j++) pv[ply][j] = pv[ply + 1][j];
                pvLen[ply] = Math.max(ply + 1, pvLen[ply + 1]);
                if (alpha >= beta) {
                    if (quiet && killers[ply][0] != m) {
                        killers[ply][1] = killers[ply][0];
                        killers[ply][0] = m;
                    }
                    break;
                }
            }
        }
        if (legal == 0) return inCheck ? -MATE + ply : 0;
        return alpha;
    }

    private int quiesce(int alpha, int beta, int ply) {
        pvLen[ply] = ply;
        if ((++nodes & 2047) == 0 && System.nanoTime() > deadline) stop = true;
        if (stop) return 0;
        int stand = evaluate();
        if (ply >= MAXPLY) return stand;
        if (stand >= beta) return stand;
        if (stand > alpha) alpha = stand;

        int[] moves = moveBuf[ply];
        int[] sc = scoreBuf[ply];
        int n = pos.gen(moves, true);
        for (int i = 0; i < n; i++) sc[i] = orderScore(moves[i], ply);
        for (int i = 0; i < n; i++) {
            int bi = i;
            for (int j = i + 1; j < n; j++) if (sc[j] > sc[bi]) bi = j;
            if (bi != i) {
                int tm = moves[i]; moves[i] = moves[bi]; moves[bi] = tm;
                int ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts;
            }
            pos.make(moves[i]);
            if (pos.moverInCheck()) {
                pos.unmake();
                continue;
            }
            int score = -quiesce(-beta, -alpha, ply + 1);
            pos.unmake();
            if (stop) return 0;
            if (score >= beta) return score;
            if (score > alpha) alpha = score;
        }
        return alpha;
    }

    /** Оцінка з точки зору того, хто ходить, у сантипішаках. */
    private int evaluate() {
        int[] b = pos.board;
        int score = 0, npm = 0, kingMg = 0, kingEg = 0, wBishops = 0, bBishops = 0;
        Arrays.fill(wP, 0);
        Arrays.fill(bP, 0);
        Arrays.fill(maxB, -1);
        Arrays.fill(minW, 8);
        for (int sq = 0; sq < 64; sq++) {
            int p = b[sq];
            if (p == 0) continue;
            int t = Math.abs(p);
            int r = sq >> 3, f = sq & 7;
            int s = p > 0 ? 1 : -1;
            int idx = p > 0 ? (7 - r) * 8 + f : r * 8 + f;
            switch (t) {
                case Position.PAWN:
                    score += s * (100 + PST_P[idx]);
                    if (p > 0) {
                        wP[f]++;
                        if (r < minW[f]) minW[f] = r;
                    } else {
                        bP[f]++;
                        if (r > maxB[f]) maxB[f] = r;
                    }
                    break;
                case Position.KNIGHT:
                    score += s * (320 + PST_N[idx]);
                    npm += 320;
                    break;
                case Position.BISHOP:
                    score += s * (330 + PST_B[idx]);
                    npm += 330;
                    if (p > 0) wBishops++;
                    else bBishops++;
                    break;
                case Position.ROOK:
                    score += s * (500 + PST_R[idx]);
                    npm += 500;
                    break;
                case Position.QUEEN:
                    score += s * (900 + PST_Q[idx]);
                    npm += 900;
                    break;
                default:
                    kingMg += s * PST_KM[idx];
                    kingEg += s * PST_KE[idx];
                    break;
            }
        }
        score += npm <= 2600 ? kingEg : kingMg;
        if (wBishops >= 2) score += 30;
        if (bBishops >= 2) score -= 30;
        for (int sq = 0; sq < 64; sq++) {
            int p = b[sq];
            if (p == 0) continue;
            int t = Math.abs(p);
            int r = sq >> 3, f = sq & 7;
            if (t == Position.ROOK) {
                if (p > 0 && wP[f] == 0) score += bP[f] == 0 ? 15 : 8;
                if (p < 0 && bP[f] == 0) score -= wP[f] == 0 ? 15 : 8;
            } else if (t == Position.PAWN) {
                boolean passed = true;
                for (int g = Math.max(0, f - 1); g <= Math.min(7, f + 1); g++) {
                    if (p > 0 ? maxB[g] > r : minW[g] < r) {
                        passed = false;
                        break;
                    }
                }
                if (passed) score += p > 0 ? PASSED[r] : -PASSED[7 - r];
            }
        }
        score = pos.whiteToMove ? score : -score;
        return score + 8;
    }
}

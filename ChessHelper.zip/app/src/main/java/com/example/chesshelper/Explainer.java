package com.example.chesshelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Перетворює результат пошуку на зрозуміле пояснення: чому цей хід найкращий. */
public class Explainer {
    private static final String[] NAME = {"", "пішак", "кінь", "слон", "тура", "ферзь", "король"};
    private static final String[] ACC = {"", "пішака", "коня", "слона", "туру", "ферзя", "короля"};
    private static final String[] INSTR = {"", "пішаком", "конем", "слоном", "турою", "ферзем", "королем"};
    private static final int[] VALUE = {0, 1, 3, 3, 5, 9, 0};

    private static String movesWord(int n) {
        int m10 = n % 10, m100 = n % 100;
        if (m10 == 1 && m100 != 11) return "хід";
        if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return "ходи";
        return "ходів";
    }

    /** Повний текст підказки. */
    public static String format(Position pos, Engine.Result res) {
        StringBuilder sb = new StringBuilder();
        int m = res.move;
        String san = pos.san(m);
        sb.append("Найкращий хід: ").append(san).append("   (")
                .append(Position.sqName(Position.from(m))).append(" → ")
                .append(Position.sqName(Position.to(m))).append(")\n");
        sb.append("Оцінка: ").append(evalText(res.score, pos.whiteToMove)).append('\n');
        sb.append("Глибина розрахунку: ").append(res.depth).append(" (півходів)\n\n");
        sb.append("Чому саме цей хід:\n");
        for (String s : explain(pos, m, res.score, res.pv)) sb.append("• ").append(s).append('\n');
        if (res.pv.length > 1) {
            sb.append("\nОчікуваний розвиток:\n").append(pvText(pos, res.pv, 6)).append('\n');
        }
        return sb.toString();
    }

    public static String evalText(int score, boolean whiteToMove) {
        if (score >= Engine.MATE - 100) {
            int n = (Engine.MATE - score + 1) / 2;
            return "мат за " + n + " " + movesWord(n) + " на користь " + (whiteToMove ? "білих" : "чорних");
        }
        if (score <= -Engine.MATE + 100) {
            int n = (Engine.MATE + score) / 2;
            if (n < 1) n = 1;
            return "мат за " + n + " " + movesWord(n) + " на користь " + (whiteToMove ? "чорних" : "білих");
        }
        int sw = whiteToMove ? score : -score;
        String num = String.format(Locale.US, "%+.2f", sw / 100.0);
        int a = Math.abs(sw);
        if (a < 25) return num + " — позиція приблизно рівна";
        String who = sw > 0 ? "білих" : "чорних";
        String size;
        if (a < 75) size = "невелика перевага";
        else if (a < 200) size = "помітна перевага";
        else if (a < 500) size = "велика перевага";
        else size = "вирішальна перевага";
        return num + " — " + size + " " + who;
    }

    public static String pvText(Position pos, int[] pv, int maxPlies) {
        Position c = pos.copy();
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (int i = 0; i < pv.length && i < maxPlies; i++) {
            int m = pv[i];
            String s = c.san(m);
            if (c.whiteToMove) sb.append(c.fullmove).append(". ").append(s).append(' ');
            else {
                if (first) sb.append(c.fullmove).append("... ");
                sb.append(s).append(' ');
            }
            first = false;
            c.make(m);
        }
        return sb.toString().trim();
    }

    public static List<String> explain(Position pos, int move, int score, int[] pv) {
        List<String> r = new ArrayList<>();
        if (move == 0) return r;
        int from = Position.from(move), to = Position.to(move), promo = Position.promo(move);
        boolean white = pos.whiteToMove;
        int piece = Math.abs(pos.board[from]);
        int victim = Math.abs(pos.board[to]);
        boolean ep = piece == Position.PAWN && to == pos.ep && (from & 7) != (to & 7) && victim == 0;
        if (ep) victim = Position.PAWN;
        boolean castle = piece == Position.KING && Math.abs(to - from) == 2;
        boolean wasCheck = pos.inCheck();

        Position c = pos.copy();
        c.make(move);
        boolean givesCheck = c.inCheck();
        boolean mates = givesCheck && !c.hasLegalMove();

        // --- мат ---
        if (mates) {
            r.add("Це мат — король суперника під шахом і порятунку немає.");
        } else if (score >= Engine.MATE - 100) {
            int n = (Engine.MATE - score + 1) / 2;
            r.add("Форсований мат за " + n + " " + movesWord(n) + ": що б не відповів суперник, мат неминучий.");
        } else if (score <= -Engine.MATE + 100) {
            int n = Math.max(1, (Engine.MATE + score) / 2);
            r.add("Позиція програшна — суперник матує за " + n + " " + movesWord(n)
                    + ". Цей хід чинить найдовший опір.");
        }

        if (wasCheck) r.add("Виводить короля з-під шаху.");

        if (castle) {
            r.add("Рокіровка: король ховається за пішаками, а тура вмикається в гру.");
        }

        // --- взяття ---
        if (victim != 0 && !mates) {
            boolean victimDefended = pos.isAttacked(to, !white);
            String sq = Position.sqName(to);
            if (!victimDefended) {
                r.add("Забирає " + ACC[victim] + " на " + sq + " — він був без захисту, це безкоштовний матеріал.");
            } else if (VALUE[victim] > VALUE[piece]) {
                r.add("Забирає " + ACC[victim] + " на " + sq + " за дешевшу фігуру — виграш матеріалу навіть після відповідного взяття.");
            } else if (VALUE[victim] == VALUE[piece]) {
                r.add("Розмін: " + NAME[piece] + " бере " + ACC[victim] + " на " + sq
                        + ". За розрахунком цей розмін вигідний у цій позиції.");
            } else {
                r.add("Забирає " + ACC[victim] + " на " + sq + ", хоч він і захищений — далі розрахунок знаходить тактичну вигоду.");
            }
        }

        // --- перетворення ---
        if (promo != 0) {
            r.add("Пішак доходить до останньої горизонталі й перетворюється: він стає " + INSTR[promo] + ".");
        }

        // --- шах ---
        if (givesCheck && !mates) {
            r.add("Дає шах — суперник змушений одразу захищати короля.");
        }

        // --- порятунок власної фігури ---
        if (piece != Position.KING && victim == 0 && !castle) {
            boolean dangerBefore = isInDanger(pos, from, white, piece);
            boolean dangerAfter = isInDanger(c, to, white, piece);
            if (dangerBefore && !dangerAfter) {
                r.add("Рятує " + ACC[piece] + " на " + Position.sqName(from) + ", якому загрожувало взяття.");
            } else if (dangerAfter && !mates && !givesCheck) {
                r.add("Увага: після ходу " + NAME[piece] + " стоїть під ударом, але за розрахунком забрати його супернику невигідно.");
            }
        }

        // --- загрози ---
        if (!mates && piece != Position.KING) {
            List<String> th = threats(c, to);
            if (!th.isEmpty()) {
                StringBuilder sb = new StringBuilder("Створює загрозу: атакує ");
                for (int i = 0; i < th.size() && i < 2; i++) {
                    if (i > 0) sb.append(" і ");
                    sb.append(th.get(i));
                }
                sb.append('.');
                r.add(sb.toString());
            }
        }

        // --- позиційні ідеї ---
        if (piece == Position.ROOK && (from & 7) != (to & 7)) {
            int f = to & 7, own = 0, enemy = 0;
            for (int rr = 0; rr < 8; rr++) {
                int p = c.board[rr * 8 + f];
                if (p == (white ? Position.PAWN : -Position.PAWN)) own++;
                if (p == (white ? -Position.PAWN : Position.PAWN)) enemy++;
            }
            if (own == 0 && enemy == 0) r.add("Тура займає відкриту вертикаль " + (char) ('a' + f) + " — звідти вона тисне на всю позицію.");
            else if (own == 0) r.add("Тура займає напіввідкриту вертикаль " + (char) ('a' + f) + " — тиск на пішаки суперника.");
        }
        int backRank = white ? 0 : 7;
        if ((piece == Position.KNIGHT || piece == Position.BISHOP) && (from >> 3) == backRank && (to >> 3) != backRank) {
            r.add("Розвиває " + ACC[piece] + ": виводить фігуру з початкового поля на активну позицію.");
        }
        boolean center = to == 27 || to == 28 || to == 35 || to == 36;
        if (center && piece != Position.KING && (from != to)) {
            r.add(piece == Position.PAWN ? "Пішак займає центр (" + Position.sqName(to) + ") — це дає простір і підтримку фігурам."
                    : "Ставить " + ACC[piece] + " у центр (" + Position.sqName(to) + ") — звідти він контролює більше полів.");
        }
        if (piece == Position.PAWN && victim == 0 && promo == 0) {
            int rel = white ? (to >> 3) : 7 - (to >> 3);
            if (rel >= 4 && isPassed(c, to, white)) {
                r.add("Просуває прохідний пішак (суперник не має пішаків, що його зупинять) — він ближче до перетворення.");
            }
        }
        if (piece == Position.KING && !castle && Engine.isEndgame(pos)) {
            r.add("В ендшпілі король — активна фігура: цей хід наближає його до центру й до дії.");
        }

        if (r.isEmpty()) {
            if (score <= -200) {
                r.add("Позиція складна: за розрахунком інші ходи програють швидше або більше — цей чинить найкращий опір.");
            } else {
                r.add("Тихий позиційний хід: покращує розташування фігур. "
                        + "Рушій перебрав варіанти й не знайшов кращого.");
            }
        }

        // --- відповідь суперника ---
        if (pv != null && pv.length > 1 && !mates) {
            r.add("Найімовірніша відповідь суперника: " + c.san(pv[1]) + ".");
        }
        return r;
    }

    /** Фігура на sq під ударом і не захищена належним чином (або її б'є дешевша фігура). */
    private static boolean isInDanger(Position p, int sq, boolean owningWhite, int type) {
        if (type == Position.KING) return false;
        if (!p.isAttacked(sq, !owningWhite)) return false;
        if (!p.isAttacked(sq, owningWhite)) return true;
        int least = p.leastAttacker(sq, !owningWhite);
        return VALUE[least] < VALUE[type];
    }

    /** Ворожі фігури, які б'є щойно походила фігура (незахищені або дорожчі за неї). */
    private static List<String> threats(Position after, int sq) {
        List<String> res = new ArrayList<>();
        Position c = after.copy();
        c.whiteToMove = !c.whiteToMove;
        c.ep = -1;
        int mover = c.board[sq];
        if (mover == 0) return res;
        boolean moverWhite = mover > 0;
        int moverType = Math.abs(mover);
        int[] buf = new int[256];
        int n = c.gen(buf, true);
        for (int i = 0; i < n; i++) {
            if (Position.from(buf[i]) != sq) continue;
            int t = Position.to(buf[i]);
            int tp = c.board[t];
            if (tp == 0) continue;
            int tt = Math.abs(tp);
            if (tt == Position.KING) continue;
            boolean defended = c.isAttacked(t, !moverWhite);
            if (!defended || VALUE[tt] > VALUE[moverType]) {
                String s = ACC[tt] + " на " + Position.sqName(t) + (defended ? "" : " (без захисту)");
                if (!res.contains(s)) res.add(s);
            }
        }
        return res;
    }

    private static boolean isPassed(Position c, int sq, boolean white) {
        int r = sq >> 3, f = sq & 7;
        int enemyPawn = white ? -Position.PAWN : Position.PAWN;
        for (int g = Math.max(0, f - 1); g <= Math.min(7, f + 1); g++) {
            if (white) {
                for (int rr = r + 1; rr <= 7; rr++) if (c.board[rr * 8 + g] == enemyPawn) return false;
            } else {
                for (int rr = r - 1; rr >= 0; rr--) if (c.board[rr * 8 + g] == enemyPawn) return false;
            }
        }
        return true;
    }
}
